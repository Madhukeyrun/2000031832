Output in PostMan:

![image](https://user-images.githubusercontent.com/87435152/235309077-c41cade7-9a79-4514-b16f-39b286456cfe.png)

Output in Google :

![image](https://user-images.githubusercontent.com/87435152/235309108-46a6614e-54f4-4fb2-a727-10f8dda7c169.png)
